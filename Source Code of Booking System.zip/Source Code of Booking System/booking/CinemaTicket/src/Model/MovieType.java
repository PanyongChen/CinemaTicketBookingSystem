package Model;
//Class MovieType will save the details of the movie type related information
//Objects of the MovieType class will be created to send the movie type details from one function to another
public class MovieType {
    //Data members for the MovieType class
    int movietypeid;
    String movietypename;
    //Getter method for movietypeid
    public int getMovietypeid() {
        return movietypeid;
    }
    //Setter method for movietypeid
    public void setMovietypeid(int movietypeid) {
        this.movietypeid = movietypeid;
    }
    //Getter method for movietypename
    public String getMovietypename() {
        return movietypename;
    }
    //Setter method for movietypename
    public void setMovietypename(String movietypename) {
        this.movietypename = movietypename;
    }
    //Constructor for the MovieType class
    public MovieType(int movietypeid, String movietypename) {
        this.movietypeid = movietypeid;
        this.movietypename = movietypename;
    }
}
