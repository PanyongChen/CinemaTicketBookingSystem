/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Timestamp;

public class ShowTime {
    int showtimeId;
    int movieId;
    Timestamp showtime;

    public ShowTime(int showtimeId, int movieId, Timestamp showtime) {
        this.showtimeId = showtimeId;
        this.movieId = movieId;
        this.showtime = showtime;
    }

    
    public int getShowtimeId() {
        return showtimeId;
    }

    public void setShowtimeId(int showtimeId) {
        this.showtimeId = showtimeId;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public Timestamp getShowtime() {
        return showtime;
    }

    public void setShowtime(Timestamp showtime) {
        this.showtime = showtime;
    }
    
}
