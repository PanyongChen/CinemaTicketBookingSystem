package Model;

import DAO.MovieDAO;
import DAO.MovieTypeDAO;
import java.sql.Timestamp;
//Class movie will save the details of the movie related information
//Objects of the movie class will be created to send the movie details from one function to another

public class Movie {
    //Data members for the movie class
    int movieid;
    String moviename;
    String moviedesc;
    String movieimage;
    int movietypeid;
    String movieaddress;
    String moviecity;
    String moviestate;
    String moviecountry;
    String moviezip;
    String movieRating;
    Timestamp moviereleasedate;
    //Constructor for the movie class
    public Movie(int movieid, String moviename, String moviedesc, String movieimage,int movietypeid, String movieaddress, String moviecity, String moviestate, String moviecountry, String moviezip, Timestamp moviereleasedate) {
        this.movieid = movieid;
        this.moviename = moviename;
        this.moviedesc = moviedesc;
        this.movieimage = movieimage;
        this.movietypeid = movietypeid;
        this.movieaddress = movieaddress;
        this.moviecity = moviecity;
        this.moviestate = moviestate;
        this.moviecountry = moviecountry;
        this.moviezip = moviezip;
        this.moviereleasedate = moviereleasedate;
    }
    //Getter method for movieid
    public int getMovieid() {
        return movieid;
    }
    //Setter method for movieid
    public void setMovieid(int movieid) {
        this.movieid = movieid;
    }
    //Getter method for moviename
    public String getMoviename() {
        return moviename;
    }
    //Setter method for moviename
    public void setMoviename(String moviename) {
        this.moviename = moviename;
    }
    //Getter method for moviedesc
    public String getMoviedesc() {
        return moviedesc;
    }
    //Setter method for moviedesc
    public void setMoviedesc(String moviedesc) {
        this.moviedesc = moviedesc;
    }
    //Getter method for movieimage
    public String getMovieimage() {
        return movieimage;
    }
    //Setter method for movieimage
    public void setMovieimage(String movieimage) {
        this.movieimage = movieimage;
    }
   
    //Getter method for movietypeid
    public int getMovietypeid() {
        return movietypeid;
    }
    //Setter method for movietypeid
    public void setMovietypeid(int movietypeid) {
        this.movietypeid = movietypeid;
    }
    //Getter method for movieaddress
    public String getMovieaddress() {
        return movieaddress;
    }
    //Setter method for movieaddress
    public void setMovieaddress(String movieaddress) {
        this.movieaddress = movieaddress;
    }
    //Getter method for moviecity
    public String getMoviecity() {
        return moviecity;
    }
    //Setter method for moviecity
    public void setMoviecity(String moviecity) {
        this.moviecity = moviecity;
    }
    //Getter method for moviestate
    public String getMoviestate() {
        return moviestate;
    }
    //Setter method for moviestate
    public void setMoviestate(String moviestate) {
        this.moviestate = moviestate;
    }
    //Getter method for moviecountry
    public String getMoviecountry() {
        return moviecountry;
    }
    //Setter method for moviecountry
    public void setMoviecountry(String moviecountry) {
        this.moviecountry = moviecountry;
    }
    //Getter method for moviezip
    public String getMoviezip() {
        return moviezip;
    }
    //Setter method for moviezip
    public void setMoviezip(String moviezip) {
        this.moviezip = moviezip;
    }
    //Getter method for moviereleasedate
    public Timestamp getMoviereleasedate() {
        return moviereleasedate;
    }
    //Setter method for moviereleasedate
    public void setMoviereleasedate(Timestamp moviereleasedate) {
        this.moviereleasedate = moviereleasedate;
    }
    public String getMovieType()
    {
        MovieTypeDAO movieTypeDAO=new MovieTypeDAO();
        return movieTypeDAO.getMovieType(movietypeid);
    }
  
    
}
