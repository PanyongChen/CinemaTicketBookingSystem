package Model;
//Class User will save the details of the user related information
//Objects of the User class will be created to send the user details from one function to another
public class User {
    //Data members for the User class
    int userid;
    String username;
    String password;
    String name;
    String phone;
    String email;
    String address;
    String city;
    String state;
    String country;
    String zip;
    String usertype;
    //Constructor for the User class
    public User(int userid, String username, String password, String name, String phone, String email, String address, String city, String state, String country, String zip, String usertype) {
        this.userid = userid;
        this.username = username;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.city = city;
        this.state = state;
        this.country = country;
        this.zip = zip;
        this.usertype = usertype;
    }
    //Getter method for userid
    public int getUserid() {
        return userid;
    }
    //Getter method for username
    public String getUsername() {
        return username;
    }
    //Getter method for password
    public String getPassword() {
        return password;
    }
    //Getter method for name
    public String getName() {
        return name;
    }
    //Getter method for phone
    public String getPhone() {
        return phone;
    }
    //Getter method for email
    public String getEmail() {
        return email;
    }
    //Getter method for address
    public String getAddress() {
        return address;
    }
    //Getter method for city
    public String getCity() {
        return city;
    }
    //Getter method for state
    public String getState() {
        return state;
    }
    //Getter method for country
    public String getCountry() {
        return country;
    }
    //Getter method for zip
    public String getZip () {
        return zip;
    }
    //Getter method for usertype
    public String getUsertype() {
        return usertype;
    }
    //Setter method for userid
    public void setUserid(int userid) {
        this.userid = userid;
    }
    //Setter method for username
    public void setUsername(String username) {
        this.username = username;
    }
    //Setter method for password
    public void setPassword(String password) {
        this.password = password;
    }
    //Setter method for name
    public void setName(String name) {
        this.name = name;
    }
    //Setter method for phone
    public void setPhone(String phone) {
        this.phone = phone;
    }
    //Setter method for email
    public void setEmail(String email) {
        this.email = email;
    }
    //Setter method for address
    public void setAddress(String address) {
        this.address = address;
    }
    //Setter method for city
    public void setCity(String city) {
        this.city = city;
    }
    //Setter method for state
    public void setState(String state) {
        this.state = state;
    }
    //Setter method for country
    public void setCountry(String country) {
        this.country = country;
    }
    //Setter method for zip
    public void setZip(String zip) {
        this.zip = zip;
    }
    //Setter method for usertype
    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }
}
