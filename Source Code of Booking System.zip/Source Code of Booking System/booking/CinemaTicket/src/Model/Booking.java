package Model;

//Class Booking will save the details of the booking related information
//Objects of the Booking class will be created to send the booking details from one function to another
public class Booking {
    //Data members for the booking class
    int bookingid;
    int bookedby;
    int numseats;
    int showtimeid;

    //Constructor for the Booking class
    public Booking(int bookingid, int bookedby, int numseats,int showtimeid) {
        this.bookingid = bookingid;
        this.bookedby = bookedby;
        this.numseats = numseats;
        this.showtimeid=showtimeid;
    }
    //Getter method for showtimeid
    public int getShowtimeid() {
        return showtimeid;
    }
    //Setter method for movieid
    public void setShowtimeid(int showtimeid) {
        this.showtimeid = showtimeid;
    }
    //Getter method for bookingid
    public int getBookingid() {
        return bookingid;
    }
    //Setter method for bookingid
    public void setBookingid(int bookingid) {
        this.bookingid = bookingid;
    }
    //Getter method for bookedby
    public int getBookedby() {
        return bookedby;
    }
    //Setter method for bookedby
    public void setBookedby(int bookedby) {
        this.bookedby = bookedby;
    }
    //Getter method for numseats
    public int getNumseats() {
        return numseats;
    }
    //Setter method for numseats
    public void setNumseats(int numseats) {
        this.numseats = numseats;
    }
}
