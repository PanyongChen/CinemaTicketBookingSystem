package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Model.Movie;

public class MovieDAO  extends BaseDAO{
	
	public MovieDAO() {
         //   connectionString = "jdbc:mysql://182.50.133.175:3306/cinematicket?autoReconnect=true&useSSL=false";
	// db_username = "cinematicket";
	// db_password = "Cinema@123";
            
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception ex) {

		}
	}
	
	//This function will be used to insert the details of newly created movie in the database.
	    public int insertMovieDetails(Movie movie) {
	        int retVal = -1;
	        try {
	            Class.forName("com.mysql.jdbc.Driver");
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("INSERT INTO `j_flor_tbl_movies` (`movieid` ,`moviename` ,`moviedesc` ,`movieimage` ,`movietypeid` ,`movieaddress` ,`moviecity` ,`moviestate` ,`moviecountry` ,`moviezip` ,`moviereleasedate`) VALUES (NULL ,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?)");
	            pst.setString(1, movie.getMoviename());
	            pst.setString(2, movie.getMoviedesc());
	            pst.setString(3, movie.getMovieimage());
	            pst.setInt(4, movie.getMovietypeid());
	            pst.setString(5, movie.getMovieaddress());
	            pst.setString(6, movie.getMoviecity());
	            pst.setString(7, movie.getMoviestate());
	            pst.setString(8, movie.getMoviecountry());
	            pst.setString(9, movie.getMoviezip());
	            pst.setTimestamp(10, movie.getMoviereleasedate());
	            pst.execute();
	            return 0;
	        } catch (Exception e) {
	            e.printStackTrace();
	            retVal = -999;
	        }
	        return retVal;
	    }

	    //This function will be used to update the details of movie in the database.
	    public int updateMovieDetails(Movie movie) {
	        int retVal = -1;
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("UPDATE `j_flor_tbl_movies` SET `moviename` =? ,`moviedesc`=? ,`movieimage`=? ,`movietypeid` =?,`movieaddress` =?,`moviecity` =?,`moviestate` =?,`moviecountry` =?,`moviezip` =?,`moviereleasedate` =? WHERE movieid =?");
	            pst.setString(1, movie.getMoviename());
	            pst.setString(2, movie.getMoviedesc());
	            pst.setString(3, movie.getMovieimage());
	            pst.setInt(4, movie.getMovietypeid());
	            pst.setString(5, movie.getMovieaddress());
	            pst.setString(6, movie.getMoviecity());
	            pst.setString(7, movie.getMoviestate());
	            pst.setString(8, movie.getMoviecountry());
	            pst.setString(9, movie.getMoviezip());
	            pst.setTimestamp(10, movie.getMoviereleasedate());
	            pst.setInt(11, movie.getMovieid());
	            pst.execute();
	            return 0;
	        } catch (Exception e) {
	            retVal = -999;
	        }
	        return retVal;
	    }
	//This function will be used to get the details of any movie using the movie id.
	    public Movie getMovieDetails(int movieId) {
	        Movie movie = null;
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("SELECT * FROM j_flor_tbl_movies  WHERE movieid=?");
	            pst.setInt(1, movieId);
	            ResultSet rs = pst.executeQuery();
	            if (rs.next()) {
	                movie = new Movie(rs.getInt("movieid"), rs.getString("moviename"), rs.getString("moviedesc"), rs.getString("movieimage"), rs.getInt("movietypeid"), rs.getString("movieaddress"), rs.getString("moviecity"), rs.getString("moviestate"), rs.getString("moviecountry"), rs.getString("moviezip"), rs.getTimestamp("moviereleasedate"));
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return movie;
	    }
            
            //This function will be used to delete the details of any movie using the movie id.
	    public void deleteMovie(int movieId) {
	       
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("DELETE FROM j_flor_tbl_movies  WHERE movieid=?");
	            pst.setInt(1, movieId);
	            pst.execute();	            
	            con.close();
	        } catch (Exception e) {
                    e.printStackTrace();
	        }	        
	    }
	    //This function will be used to get a list of all the movies in the database.
	    public List<Movie> getAllMovies() {
	        List<Movie> movies = new ArrayList<Movie>();
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("Select * from j_flor_tbl_movies");
	            ResultSet rs = pst.executeQuery();
	            while (rs.next()) {
	                Movie movie = new Movie(rs.getInt("movieid"), rs.getString("moviename"), rs.getString("moviedesc"), rs.getString("movieimage"), rs.getInt("movietypeid"), rs.getString("movieaddress"), rs.getString("moviecity"), rs.getString("moviestate"), rs.getString("moviecountry"), rs.getString("moviezip"), rs.getTimestamp("moviereleasedate"));
	                movies.add(movie);
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return movies;
	    }
	//This function will be used to search the movies in the database using the name of the movie.
	// This will return the list of movies which contains the search phrase in the name.
	    public List<Movie> searchMoviesByName(String name) {
	        List<Movie> movies = new ArrayList<Movie>();
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("Select * from j_flor_tbl_movies  WHERE moviename like  '%" + name + "%'");
	            ResultSet rs = pst.executeQuery();
	            while (rs.next()) {
	                Movie movie = new Movie(rs.getInt("movieid"), rs.getString("moviename"), rs.getString("moviedesc"), rs.getString("movieimage"), rs.getInt("movietypeid"), rs.getString("movieaddress"), rs.getString("moviecity"), rs.getString("moviestate"), rs.getString("moviecountry"), rs.getString("moviezip"), rs.getTimestamp("moviereleasedate"));
	                movies.add(movie);
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return movies;
	    }
	//This function will be used to search the movies in the database using the name of the movie and the city of the movie.
	// This will return the list of movies which contains the search phrase in the name and has the same city.
	    public List<Movie> searchMoviesByNameCity(String name, String city) {
	        List<Movie> movies = new ArrayList<Movie>();
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("Select * from j_flor_tbl_movies  WHERE moviename like  '%" + name + "%' and moviecity like '%" + city + "%'");
	            ResultSet rs = pst.executeQuery();
	            while (rs.next()) {
	                Movie movie = new Movie(rs.getInt("movieid"), rs.getString("moviename"), rs.getString("moviedesc"), rs.getString("movieimage"), rs.getInt("movietypeid"), rs.getString("movieaddress"), rs.getString("moviecity"), rs.getString("moviestate"), rs.getString("moviecountry"), rs.getString("moviezip"), rs.getTimestamp("moviereleasedate"));
	                movies.add(movie);
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return movies;
	    }
	//This function will be used to search the movies in the database using the name of the movie, the city and movie type of the movie.
	// This will return the list of movies which contains the search phrase in the name and has the same city and movie type.
	    public List<Movie> searchMoviesByNameCityType(String name, String city, int type) {
	        List<Movie> movies = new ArrayList<Movie>();
	        try {
	           Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	             PreparedStatement pst = con.prepareStatement("Select * from j_flor_tbl_movies  WHERE movietypeid=? AND moviename like  '%" + name + "%' and moviecity like '%" + city + "%'");
	            pst.setInt(1, type);
	            ResultSet rs = pst.executeQuery();
	            while (rs.next()) {
	                Movie movie = new Movie(rs.getInt("movieid"), rs.getString("moviename"), rs.getString("moviedesc"), rs.getString("movieimage"), rs.getInt("movietypeid"), rs.getString("movieaddress"), rs.getString("moviecity"), rs.getString("moviestate"), rs.getString("moviecountry"), rs.getString("moviezip"), rs.getTimestamp("moviereleasedate"));
	                movies.add(movie);
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return movies;
	    }

}
