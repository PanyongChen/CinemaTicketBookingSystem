package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Model.User;

public class UserDAO  extends BaseDAO{


	public UserDAO() {
  //          connectionString = "jdbc:mysql://182.50.133.175:3306/cinematicket?autoReconnect=true&useSSL=false";
//	 db_username = "cinematicket";
//	 db_password = "Cinema@123";
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception ex) {

		}
	}

	// This is used to check if the username and password are correct at the
	// time of user login.
	// This function will be called from the controller
	public int login(String username, String password) {
		int retVal = -1;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("Select * from j_flor_tbl_users where username=? and password=?");
			pst.setString(1, username);
			pst.setString(2, password);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				retVal = rs.getInt("userid");
			}
			con.close();
		} catch (Exception e) {
			retVal = -999;
			e.printStackTrace();
		}
		return retVal;
	}

	// This is used to check if the username already exists in the system.
	// This function will be called from the register servlet.
	public int userExists(String username) {
		int retVal = -1;
		try {
			Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("Select * from j_flor_tbl_users where username=?");
			pst.setString(1, username);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				retVal = rs.getInt("userid");
			}
			con.close();
		} catch (Exception e) {
			retVal = -999;
		}
		return retVal;
	}

	// This function will be used to insert the new user details in the
	// database.
	public int insertUserDetails(User user) {
		if (userExists(user.getUsername()) > 0)
			return -2;
		int retVal = -1;
		try {
			Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement(
					"INSERT INTO  `j_flor_tbl_users` (`userid` ,`username` ,`password` ,`name` ,`phone` ,`email` ,`address` ,`city` ,`state` ,`country` ,`zip` ,`usertype`)VALUES (NULL ,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?)");
			pst.setString(1, user.getUsername());
			pst.setString(2, user.getPassword());
			pst.setString(3, user.getName());
			pst.setString(4, user.getPhone());
			pst.setString(5, user.getEmail());
			pst.setString(6, user.getAddress());
			pst.setString(7, user.getCity());
			pst.setString(8, user.getState());
			pst.setString(9, user.getCountry());
			pst.setString(10, user.getZip());
			pst.setString(11, user.getUsertype());
			pst.execute();
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			retVal = -999;
		}
		return retVal;
	}

	// This function will be used to edit the details of the user using his user
	// id.
	public int updateUserDetails(User user) {
		if (userExists(user.getUsername()) <= 0)
			return -3;
		int retVal = -1;
		try {
			Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement(
					"UPDATE  `j_flor_tbl_users` SET `username` =? ,`password` =?,`name` =?,`phone`=? ,`email` =?,`address`=? ,`city`=? ,`state`=? ,`country` =?,`zip`=? ,`usertype`=? WHERE userid = ?");
			pst.setString(1, user.getUsername());
			pst.setString(2, user.getPassword());
			pst.setString(3, user.getName());
			pst.setString(4, user.getPhone());
			pst.setString(5, user.getEmail());
			pst.setString(6, user.getAddress());
			pst.setString(7, user.getCity());
			pst.setString(8, user.getState());
			pst.setString(9, user.getCountry());
			pst.setString(10, user.getZip());
			pst.setString(11, user.getUsertype());
			pst.setInt(12, user.getUserid());
			pst.execute();
			return 0;
		} catch (Exception e) {
			retVal = -999;
		}
		return retVal;
	}

	// This function will be used to get the details of the user using his user
	// id.
	// This will be used in many different places
	public User getUserDetails(int userId) {
		User user = null;
		try {
			Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("Select * from j_flor_tbl_users where userid=?");
			pst.setInt(1, userId);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				user = new User(rs.getInt("userid"), rs.getString("username"), rs.getString("password"),
						rs.getString("name"), rs.getString("phone"), rs.getString("email"), rs.getString("address"),
						rs.getString("city"), rs.getString("state"), rs.getString("country"), rs.getString("zip"),
						rs.getString("usertype"));
			}
			con.close();
		} catch (Exception e) {
		}
		return user;
	}
}
