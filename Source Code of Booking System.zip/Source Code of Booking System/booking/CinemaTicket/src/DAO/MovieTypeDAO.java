package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Model.MovieType;

public class MovieTypeDAO  extends BaseDAO{
	
	public MovieTypeDAO() {
    
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception ex) {

		}
	}
	
	//This function will be used to return the list of movie types in the system.
	    public List<MovieType> getEventTypes() {
	        List<MovieType> movietypes = new ArrayList<MovieType>();
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("SELECT * FROM  `j_flor_tbl_movietypes` ");
	            ResultSet rs = pst.executeQuery();
	            while (rs.next()) {
	                MovieType movietype = new MovieType(rs.getInt("movietypeid"), rs.getString("movietypename"));
	                movietypes.add(movietype);
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return movietypes;
	    }
	public String getMovieType(int movieTypeId){
            try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("SELECT * FROM  `j_flor_tbl_movietypes` where movietypeid=?");
                    pst.setInt(1,movieTypeId);
	            ResultSet rs = pst.executeQuery();
	            if (rs.next()) {
	                String movieType=rs.getString("movietypename");
                        return movieType;
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return "";
        }

}
