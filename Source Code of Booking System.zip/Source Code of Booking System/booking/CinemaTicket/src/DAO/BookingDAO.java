package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Model.Booking;

public class BookingDAO  extends BaseDAO{

	

	public BookingDAO() {
   //      connectionString = "jdbc:mysql://182.50.133.175:3306/cinematicket?autoReconnect=true&useSSL=false";
	// db_username = "cinematicket";
//	 db_password = "Cinema@123";
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception ex) {

		}
	}
	
	//This function is used to insert a new booking for seats for any movie done by any user.
	    public int insertBooking(Booking booking) {
	        int retVal = -1;
	        try {
	            Class.forName("com.mysql.jdbc.Driver");
	           Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	             PreparedStatement pst = con.prepareStatement("INSERT INTO  `j_flor_tbl_bookings` (`bookedby` ,`numseats`,`movieid`) VALUES (?,  ?,?)");
	            pst.setInt(1, booking.getBookedby());
	            pst.setInt(2, booking.getNumseats());
	            pst.setInt(3, booking.getShowtimeid());
	            pst.execute();
	            return 0;
	        } catch (Exception e) {
	            e.printStackTrace();
	            retVal = -999;
	        }
	        return retVal;
	    }
	//This function will return a list of all the bookings done by a user.
	    public List<Booking> getBookings(int bookedby) {
	        List<Booking> bookings = new ArrayList<Booking>();
	        try {
	           Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	             PreparedStatement pst = con.prepareStatement("SELECT * FROM j_flor_tbl_bookings WHERE (bookedby=" + bookedby + ")");
	            ResultSet rs = pst.executeQuery();
	            while (rs.next()) {
	                Booking booking = new Booking(rs.getInt("bookingid"), rs.getInt("bookedby"), rs.getInt("numseats"), rs.getInt("movieid"));
	                bookings.add(booking);
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return bookings;
	    }
	
}
