/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Movie;
import Model.ShowTime;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class ShowTimeDAO  extends BaseDAO{
    
    //This function will be used to insert the details of newly created showtim in the database.
	    public int insertShowtimeDetails(ShowTime showtime) {
	        int retVal = -1;
	        try {
	            Class.forName("com.mysql.jdbc.Driver");
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("INSERT INTO `j_flor_tbl_showtime` (`showtimeid`,`movieid` ,`showtime`) VALUES (NULL ,  ?,  ?)");
	            pst.setInt(1, showtime.getMovieId());	           
	            pst.setTimestamp(2, showtime.getShowtime());
	            pst.execute();
	            return 0;
	        } catch (Exception e) {
	            e.printStackTrace();
	            retVal = -999;
	        }
	        return retVal;
	    }
            
             //This function will be used to delete the details of any showtime using the showtime id.
	    public void deleteShowtime(int showtimeId) {
	       
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("DELETE FROM j_flor_tbl_showtime  WHERE showtimeid=?");
	            pst.setInt(1, showtimeId);
	            pst.execute();	            
	            con.close();
	        } catch (Exception e) {
                    e.printStackTrace();
	        }	        
	    }
            //This function will be used to get a list of all the showtimes for a movie in the database.
	    public List<ShowTime> getAllShowtimes(int movieId) {
	        List<ShowTime> showtimes = new ArrayList<ShowTime>();
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("Select * from j_flor_tbl_showtime where movieid=? order by showtime ");
                    pst.setInt(1, movieId);
	            ResultSet rs = pst.executeQuery();
	            while (rs.next()) {
	                ShowTime showtime = new ShowTime(rs.getInt("showtimeid"),rs.getInt("movieid"), rs.getTimestamp("showtime"));
	                showtimes.add(showtime);
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return showtimes;
	    }
            //This function will be used to get a list of all the showtimes 
	    public List<ShowTime> getAllShowtimes() {
	        List<ShowTime> showtimes = new ArrayList<ShowTime>();
	        try {
	            Connection con = DriverManager.getConnection(getConnectionString(), getDb_username(), getDb_password());
	            PreparedStatement pst = con.prepareStatement("Select * from j_flor_tbl_showtime order by showtime ");
                   
	            ResultSet rs = pst.executeQuery();
	            while (rs.next()) {
	                ShowTime showtime = new ShowTime(rs.getInt("showtimeid"),rs.getInt("movieid"), rs.getTimestamp("showtime"));
	                showtimes.add(showtime);
	            }
	            con.close();
	        } catch (Exception e) {
	        }
	        return showtimes;
	    }
    
}
