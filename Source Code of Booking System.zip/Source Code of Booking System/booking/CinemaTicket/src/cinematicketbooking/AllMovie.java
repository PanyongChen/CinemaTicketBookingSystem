/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.MovieDAO;
import Model.Movie;
import cinematicketbooking.UserSearchMovies.MovieData;

import java.awt.Insets;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AllMovie extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        Menu customerMenu = new Menu("Customers");
        // Create MenuItems
        MenuItem createMovieItem = new MenuItem("Create Movie");
        MenuItem allMovieItem = new MenuItem("All Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(createMovieItem, allMovieItem);

        createMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                CreateMovie createMovie = new CreateMovie();
                createMovie.start(primaryStage);
            }
        });

        allMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                AllMovie allMovie = new AllMovie();
                allMovie.start(primaryStage);
            }
        });
;
        // Add Menus to the MenuBar
		Menu accountMenu = new Menu("Go");
		MenuItem gotoLogin = new MenuItem("back");
		accountMenu.getItems().addAll(gotoLogin);
		gotoLogin.setOnAction(new EventHandler<ActionEvent>() {
		
		    @Override
		    public void handle(ActionEvent event) {
		    	AdminHome login = new AdminHome();
		        login.start(primaryStage);
		    }
		});
		menuBar.getMenus().addAll(moviesMenu, accountMenu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        
        Text scenetitle = new Text("List of all movies in the system!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2,4); 
        
        TableView table = new TableView();
        
        TableColumn movieNameCol = new TableColumn("Movie Name");
        movieNameCol.setMinWidth(200);
        movieNameCol.setCellValueFactory(new PropertyValueFactory<>("movieName"));

        TableColumn movieCityCol = new TableColumn("City");
        movieCityCol.setMinWidth(150);
        movieCityCol.setCellValueFactory(new PropertyValueFactory<>("city"));
        
        TableColumn movieTypeCol = new TableColumn("Movie Type");
        movieTypeCol.setCellValueFactory(new PropertyValueFactory<>("movieType"));
        movieTypeCol.setMinWidth(150);
        TableColumn movieRating = new TableColumn("Movie Rating");
        movieRating.setCellValueFactory(new PropertyValueFactory<>("movieRating"));
        movieRating.setMinWidth(100);
        MovieDAO movieDAO=new MovieDAO();
        List<Movie> movies= movieDAO.getAllMovies();
        final ObservableList<MovieData> data
            = FXCollections.observableArrayList(       
                  
                    
            );

        int rateI = 0,p;
        for(Movie movie:movies){
     	    String rate = new String();
     	    int rValue = getRating(rateI);
     	    for(p = 0; p < rValue; p ++) {
     	    	rate += "*";
     	    }
             data.add(new MovieData(movie.getMoviename(),movie.getMoviecity(),movie.getMovieType(), rate));
         }

       
        table.setItems(data); 
        table.getColumns().addAll(movieNameCol,movieCityCol,movieTypeCol,movieRating);
        
        
        Button btnView = new Button();
        btnView.setText("View Detail");
        btnView.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);
                AdminViewMovie adminViewMovie = new AdminViewMovie(movies.get(index).getMovieid());
                adminViewMovie.start(primaryStage);
            }
        });
        grid.add(btnView, 2, 5);
        
        Button btnEdit = new Button();
        btnEdit.setText("Edit Details");
        btnEdit.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                System.out.println(table.getSelectionModel().getSelectedIndex());
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);
                AdminEditMovie adminEditMovie = new AdminEditMovie(movies.get(index).getMovieid());
                adminEditMovie.start(primaryStage);
            }
        });
        grid.add(btnEdit, 2, 6);
        
        Button btnDelete = new Button();
        btnDelete.setText("Delete Movie");
        btnDelete.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                System.out.println(table.getSelectionModel().getSelectedIndex());
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);
                MovieDAO movieDAO=new MovieDAO();
                movieDAO.deleteMovie(movies.get(index).getMovieid());
                AllMovie allMovie = new AllMovie();
                allMovie.start(primaryStage);
            }
        });
        grid.add(btnDelete, 2, 7);
        
        grid.add(table, 2, 8);
        
        

        Scene scene = new Scene(root, 700, 550);

        primaryStage.setTitle("All Movies!");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

    public static int getRating(int i) {
    	Random rand = new Random();
    	int  n = rand.nextInt(50) + i;
    	return n % 5 + 1;
    }
    public static class MovieData {

        private final SimpleStringProperty movieName;
        private final SimpleStringProperty city;
        private final SimpleStringProperty movieType;
        private final SimpleStringProperty movieRating;
        private MovieData(String movieName,String city, String movieType, String movieRating) {
            this.movieName = new SimpleStringProperty(movieName);
            this.city = new SimpleStringProperty(city);
            this.movieType = new SimpleStringProperty(movieType);
            this.movieRating = new SimpleStringProperty(movieRating);
        }

        public String getMovieName() {
            return movieName.get();
        }
        public String getMovieRating() {
        	return movieRating.get();
        }
       

        public String getCity() {
            return city.get();
        }

        public String getMovieType() {
            return movieType.get();
        }

       
    }
}