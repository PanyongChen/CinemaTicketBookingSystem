/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import java.awt.Insets;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class CustomerHome extends Application {
    int userid;
    public CustomerHome(int userid)
    {
        this.userid=userid;
    }
    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        // Create MenuItems
        MenuItem allMoviesItem = new MenuItem("All Movies");
        MenuItem searchMoviesItem = new MenuItem("Search Movies");
  
        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(allMoviesItem, searchMoviesItem);

        allMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserAllMovie userAllMovie = new UserAllMovie(userid);
                userAllMovie.start(primaryStage);
            }
        });

        searchMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserSearchMovies userSearchMovie = new UserSearchMovies(userid);
                userSearchMovie.start(primaryStage);
            }
        });
       
        Menu bookingsMenu = new Menu("Bookings");
        // Create MenuItems
        MenuItem myBookingsItem = new MenuItem("My Bookings");
        
        bookingsMenu.getItems().addAll(myBookingsItem);
        myBookingsItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserBookings userBookings = new UserBookings(userid);
                userBookings.start(primaryStage);
            }
        });

        Menu accountMenu = new Menu("Account");
        MenuItem gotoLogin = new MenuItem("Log out");
        accountMenu.getItems().addAll(gotoLogin);
        gotoLogin.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            	Login login = new Login();
                login.start(primaryStage);
            }
        });
        // Add Menus to the MenuBar
        menuBar.getMenus().addAll(moviesMenu,bookingsMenu,accountMenu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        
        Text scenetitle = new Text("Welcome To Cinema Booking User Panel!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2,4);
        
        Text registermmessage = new Text("You can search for movies!");
        registermmessage.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(registermmessage, 2,5);
        
        Text loginmessage = new Text("You can book movies!");
        loginmessage.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(loginmessage, 2,6);
        
        Text bookingmessage = new Text("You can check and edit prvious bookings!");
        bookingmessage.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(bookingmessage, 2,7);

        root.getStyleClass().add("normalImage");
        Scene scene = new Scene(root, 500, 625);
        scene.getStylesheets().add(getClass().getResource("Hom.css").toExternalForm());
        primaryStage.setTitle("Welcome!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}

   
