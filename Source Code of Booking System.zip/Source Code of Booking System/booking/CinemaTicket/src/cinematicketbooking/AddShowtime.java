/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.MovieDAO;
import DAO.MovieTypeDAO;
import DAO.ShowTimeDAO;
import DAO.UserDAO;
import Model.Movie;
import Model.MovieType;
import Model.ShowTime;
import Model.User;
import java.awt.Insets;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AddShowtime extends Application {
    
    int movieId; 
    public AddShowtime()
    {
        this.movieId=48;
    }
    public AddShowtime(int movieId)
    {
        this.movieId=movieId;
    }

    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        Menu customerMenu = new Menu("Customers");
        // Create MenuItems
        MenuItem createMovieItem = new MenuItem("Create Movie");
        MenuItem allMovieItem = new MenuItem("All Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(createMovieItem, allMovieItem);

        createMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                CreateMovie createMovie = new CreateMovie();
                createMovie.start(primaryStage);
            }
        });

        allMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                AllMovie allMovie = new AllMovie();
                allMovie.start(primaryStage);
            }
        });
;
        // Add Menus to the MenuBar
		Menu accountMenu = new Menu("Go");
		MenuItem gotoLogin = new MenuItem("back");
		accountMenu.getItems().addAll(gotoLogin);
		gotoLogin.setOnAction(new EventHandler<ActionEvent>() {
		
		    @Override
		    public void handle(ActionEvent event) {
		    	AdminHome login = new AdminHome();
		        login.start(primaryStage);
		    }
		});
	    menuBar.getMenus().addAll(moviesMenu,accountMenu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        MovieDAO movieDAO=new MovieDAO();
        
        Text scenetitle = new Text("Add show time");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2,4); 
        
        grid.add(new Label("Show Date:"), 2, 5);
        DatePicker movieDate = new DatePicker();
        grid.add(movieDate, 3, 5);
        
        grid.add(new Label("Hour:"), 2, 6);
        ListView<String> list = new ListView<String>();     
        ObservableList<String> items =FXCollections.observableArrayList ();
        for(int i=0;i<24;i++)
            items.add(i+"");
        list.setItems(items);
        list.setMaxHeight(100);
        grid.add(list, 3, 6);
        
        grid.add(new Label("Minute:"), 2, 7);
        ListView<String> list2 = new ListView<String>();     
        ObservableList<String> items2 =FXCollections.observableArrayList ();
        for(int i=0;i<59;i++)
            items2.add(i+"");
        list2.setItems(items2);
        list2.setMaxHeight(100);
        grid.add(list2, 3, 7);
                  
        Button btnAdd = new Button();
        btnAdd.setText("Add ShowTime");
         Label resgisterMessage = new Label("");
        btnAdd.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
             ShowTimeDAO showtimeDAO = new ShowTimeDAO();
             int year=movieDate.getValue().getYear();
             int month=movieDate.getValue().getMonthValue();
             int day=movieDate.getValue().getDayOfMonth();
             int hour=Integer.parseInt(list.getSelectionModel().getSelectedItem());
             int minute=Integer.parseInt(list2.getSelectionModel().getSelectedItem());
            
               Timestamp timestamp=makeTimestamp(year,month,day,hour,minute,0,0);
               if (timestamp==null) {
                    resgisterMessage.setText("Timestamp cannot be empty!");
                } else {                    
                    ShowTime showtime=new ShowTime(-1, movieId, timestamp);
                   int res = showtimeDAO.insertShowtimeDetails(showtime);
                    System.out.println(res);
                    if (res !=0) {
                        resgisterMessage.setText("Unable to process request!");
                    }  else {
                        resgisterMessage.setText("Successful insertion!");                        
                    }
                }
            }    
            
        });
        grid.add(btnAdd, 2, 8);
        
        grid.add(resgisterMessage, 2, 9);
         
        Scene scene = new Scene(root, 700, 550);

        primaryStage.setTitle("All Showtimes!");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
    
     public static Timestamp makeTimestamp(int year, int month, int day, int hour, int minute,
      int second, int millisecond) {
    Calendar cal = new GregorianCalendar();
    cal.set(Calendar.YEAR, year);
    cal.set(Calendar.MONTH, month - 1);
    cal.set(Calendar.DATE, day);
    cal.set(Calendar.HOUR_OF_DAY, hour);
    cal.set(Calendar.MINUTE, minute);
    cal.set(Calendar.SECOND, second);
    cal.set(Calendar.MILLISECOND, millisecond);

    // now convert GregorianCalendar object to Timestamp object
    return new Timestamp(cal.getTimeInMillis());
  }


public static class MovieData {

        private final SimpleStringProperty showtime;

        private MovieData(Timestamp timestamp) {
            this.showtime = new SimpleStringProperty(new SimpleDateFormat("MM/dd/yyyy HH:mm").format(timestamp));           
        }

        public String getShowtime() {
            return showtime.get();
        }

    }
}