/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.MovieDAO;
import DAO.MovieTypeDAO;
import DAO.UserDAO;
import Model.Movie;
import Model.MovieType;
import Model.User;
import java.awt.Insets;
import java.sql.Timestamp;
import java.util.List;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AdminEditMovie extends Application {
    int movieId;
    public AdminEditMovie(int movieId)
    {
        this.movieId=movieId;
    }


    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        Menu customerMenu = new Menu("Customers");
        // Create MenuItems
        MenuItem createMovieItem = new MenuItem("Create Movie");
        MenuItem allMovieItem = new MenuItem("All Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(createMovieItem, allMovieItem);

        createMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                CreateMovie createMovie = new CreateMovie();
                createMovie.start(primaryStage);
            }
        });

        allMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                AllMovie allMovie = new AllMovie();
                allMovie.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        Menu accountMenu = new Menu("Go");
        MenuItem gotoLogin = new MenuItem("back");
        accountMenu.getItems().addAll(gotoLogin);
        gotoLogin.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            	AdminHome login = new AdminHome();
                login.start(primaryStage);
            }
        });
        menuBar.getMenus().addAll(moviesMenu, accountMenu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        
        Text scenetitle = new Text("Update Movie Form!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2, 4);
        
        MovieDAO movieDAO=new MovieDAO();
        Movie movie=movieDAO.getMovieDetails(movieId);

        Label movieName = new Label("Movie Name:");
        grid.add(movieName, 2, 5);

        TextField movieNameField = new TextField(movie.getMoviename());
        grid.add(movieNameField, 3, 5);

        grid.add(new Label("Movie Desc:"), 2, 6);
        TextField movieDescField = new TextField(movie.getMoviedesc());
        grid.add(movieDescField, 3, 6);       

        grid.add(new Label("Movie Type:"), 2, 7);
        ListView<String> list = new ListView<String>();
        MovieTypeDAO movieTypeDAO=new MovieTypeDAO();
        List<MovieType> movieTypes=movieTypeDAO.getEventTypes();
        ObservableList<String> items =FXCollections.observableArrayList ();
        for(MovieType movieType:movieTypes)
            items.add(movieType.getMovietypename());
        list.setItems(items);
        grid.add(list, 3, 7);

        grid.add(new Label("Movie Address:"), 2, 8);
        TextField addressField = new TextField(movie.getMovieaddress());
        grid.add(addressField, 3, 8);

        grid.add(new Label("City:"), 2, 9);
        TextField cityField = new TextField(movie.getMoviecity());
        grid.add(cityField, 3, 9);

        grid.add(new Label("State:"), 2, 10);
        TextField stateField = new TextField(movie.getMoviestate());
        grid.add(stateField, 3, 10);

        grid.add(new Label("Country:"), 2, 11);
        TextField countryField = new TextField(movie.getMoviecountry());
        grid.add(countryField, 3, 11);

        grid.add(new Label("Zip:"), 2, 12);
        TextField zipField = new TextField(movie.getMoviezip());
        grid.add(zipField, 3, 12);
        
        grid.add(new Label("Movie Release Date:"), 2, 13);
        DatePicker releaseDate = new DatePicker();
        grid.add(releaseDate, 3, 13);

        Scene scene = new Scene(root, 600, 560);
        Label resgisterMessage = new Label("");
        Button btnLogin = new Button();
        btnLogin.setText("Update");
        btnLogin.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                MovieDAO movieDAO = new MovieDAO();
               if (movieNameField.getText().length() == 0 || movieDescField.getText().length() == 0) {
                    resgisterMessage.setText("Movie name and descriptiont cannot be empty!");
                } else {                           
                    String name = movieNameField.getText();
                    String desc = movieDescField.getText();
                    int typeId  = movieTypes.get(list.getSelectionModel().getSelectedIndex()).getMovietypeid();
                    String address = addressField.getText();
                    String city = cityField.getText();
                    String state = stateField.getText();
                    String country = countryField.getText();
                    String zip = zipField.getText();                    
                    Timestamp releasedate= Timestamp.valueOf(releaseDate.getValue().atStartOfDay());
                    Movie movie = new Movie(movieId, name,desc,"",typeId,address,city,state,country,zip,releasedate);
                    int res = movieDAO.updateMovieDetails(movie);
                    System.out.println(res);
                    if (res !=0) {
                        resgisterMessage.setText("Unable to process request!");
                    }  else {
                        resgisterMessage.setText("Successful update!");                        
                    }
                }
            }
        });

        grid.add(btnLogin, 2, 14);

        grid.add(resgisterMessage, 2, 15);

        primaryStage.setTitle("Create Movie!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
