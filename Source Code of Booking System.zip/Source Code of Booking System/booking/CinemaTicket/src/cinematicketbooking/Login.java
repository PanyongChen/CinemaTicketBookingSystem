/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.UserDAO;
import Model.User;
import java.awt.Insets;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Login extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu menu = new Menu("Register/Login");
        // Create MenuItems
        MenuItem registerItem = new MenuItem("Register");
        MenuItem loginItem = new MenuItem("Login");

        // Add menuItems to the Menus
        menu.getItems().addAll(registerItem, loginItem);

        registerItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Register register = new Register();
                register.start(primaryStage);
            }
        });

        loginItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Login login = new Login();
                login.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        menuBar.getMenus().addAll(menu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);

        Text scenetitle = new Text("Login Form!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2, 4);

        Label userName = new Label("User Name:");
        grid.add(userName, 2, 5);

        TextField userTextField = new TextField();
        grid.add(userTextField, 3, 5);

        Label pw = new Label("Password:");
        grid.add(pw, 2, 6);

        PasswordField pwBox = new PasswordField();
        grid.add(pwBox, 3, 6);
        Scene scene = new Scene(root, 500, 400);
        Label loginMessage = new Label("");
        Button btnLogin = new Button();
        btnLogin.setText("Login");
        btnLogin.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                UserDAO userDAO=new UserDAO();
                String username=userTextField.getText();
                String password=pwBox.getText();
                int res=userDAO.login(username, password);
                System.out.println(res);
                if(res==-1)
                {
                    loginMessage.setText("Invalid username/password!");
                }
                else if(res<0)
                {
                    loginMessage.setText("Unable to process request!");
                }
                else
                {
                    loginMessage.setText("Successful login!");
                    User user=userDAO.getUserDetails(res);
                    if(user.getUsertype().equals("customer"))
                    {
                        CustomerHome customerHome = new CustomerHome(res);
                        customerHome.start(primaryStage);
                    }
                    else if(user.getUsertype().equals("admin"))
                    {
                        AdminHome adminHome = new AdminHome();
                        adminHome.start(primaryStage);
                    }
                }
            }
        });
        
        grid.add(btnLogin, 2, 7);       
        
        grid.add(loginMessage, 2, 8);


        primaryStage.setTitle("Login!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
