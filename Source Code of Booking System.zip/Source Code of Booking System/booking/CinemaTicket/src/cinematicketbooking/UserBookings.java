/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.BookingDAO;
import DAO.MovieDAO;
import DAO.ShowTimeDAO;
import Model.Booking;
import Model.Movie;
import Model.ShowTime;
import java.awt.Insets;
import java.awt.ScrollPane;
import java.util.List;
import java.util.Map;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class UserBookings extends Application{
    int userid;
    public UserBookings(int userid)
    {
        this.userid=userid;
    }
    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
         // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        // Create MenuItems
        MenuItem allMoviesItem = new MenuItem("All Movies");
        MenuItem searchMoviesItem = new MenuItem("Search Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(allMoviesItem, searchMoviesItem);

        allMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserAllMovie userAllMovie = new UserAllMovie(userid);
                userAllMovie.start(primaryStage);
            }
        });

        searchMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserSearchMovies userSearchMovie = new UserSearchMovies(userid);
                userSearchMovie.start(primaryStage);
            }
        });
        
        Menu bookingsMenu = new Menu("Bookings");
        // Create MenuItems
        MenuItem myBookingsItem = new MenuItem("My Bookings");
        bookingsMenu.getItems().addAll(myBookingsItem);
        myBookingsItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserBookings userBookings = new UserBookings(userid);
                userBookings.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        
        Menu accountMenu = new Menu("Go");
        MenuItem gotoLogin = new MenuItem("back");
        accountMenu.getItems().addAll(gotoLogin);
        gotoLogin.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            	CustomerHome login = new CustomerHome(userid);
                login.start(primaryStage);
            }
        });
        
        menuBar.getMenus().addAll(moviesMenu,bookingsMenu,accountMenu);
        
        
        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        
        Text scenetitle = new Text("List of all bookings!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2,4); 
        
        TableView table = new TableView();
        
        TableColumn movieNameCol = new TableColumn("Movie Name");
        movieNameCol.setMinWidth(200);
        movieNameCol.setCellValueFactory(new PropertyValueFactory<>("movieName"));

        TableColumn numSeatsCol = new TableColumn("Num Seats");
        numSeatsCol.setMinWidth(150);
        numSeatsCol.setCellValueFactory(new PropertyValueFactory<>("numSeats"));
               
        BookingDAO bookingDAO=new BookingDAO();
        MovieDAO movieDAO=new MovieDAO();
        List<Booking> bookings=bookingDAO.getBookings(userid);
        final ObservableList<MovieData> data
            = FXCollections.observableArrayList(       
                  
                    
            );
        ShowTimeDAO showtimeDAO=new ShowTimeDAO();
        List<ShowTime> showtimes=showtimeDAO.getAllShowtimes();
        List<Movie> movies=movieDAO.getAllMovies();
       for(Booking booking:bookings){
            int showtimeId=booking.getShowtimeid();
            int movieId=-1;
            for(ShowTime showtime:showtimes)
            {
                if(showtime.getShowtimeId()==showtimeId)
                   movieId=showtime.getMovieId();
            }
            String movieName="";
             for(Movie movie:movies)
            {
                if(movie.getMovieid()==movieId)
                   movieName=movie.getMoviename();
            }
            data.add(new MovieData(movieName,booking.getNumseats()+""));
        }
       
        table.setItems(data); 
        table.getColumns().addAll(movieNameCol,numSeatsCol);
        
        
        Button btnPay = new Button();
        btnPay.setText("Payment");
        btnPay.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                int index=table.getSelectionModel().getSelectedIndex();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("Coupon calculated");
                String str = new String("You have deducted 3 $$");
                alert.getDialogPane().setContentText("aaa");
                alert.showAndWait();
            }
        });
        grid.add(btnPay, 2, 5);
        
        Button btnView = new Button();
        btnView.setText("Edit Booking");
        btnView.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);
                UserViewMovie userViewMovie = new UserViewMovie(userid,movies.get(index).getMovieid());
                userViewMovie.start(primaryStage);
            }
        });
        grid.add(btnView, 5, 5);
        
        Button btnEdit = new Button();
        btnEdit.setText("Delete Booking");
        btnEdit.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                System.out.println(table.getSelectionModel().getSelectedIndex());
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);
                UserShowTime userShowTime = new UserShowTime(userid,movies.get(index).getMovieid());
                userShowTime.start(primaryStage);
            }
        });
        grid.add(btnEdit, 2, 6);
        grid.add(table, 2, 7);
        
        

        Scene scene = new Scene(root, 700, 500);

        primaryStage.setTitle("All Movies!");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }
    public static int Coupon(int seats) {
    	if(seats * 10 >= 500 ) {
    		return 50;
    	}else if(seats * 10 >= 100) {
    		return 10;
    	}else if(seats * 10 >= 40) {
    		return 3;
    	}
    	return 0;
    }
    public static void main(String[] args) {
        Application.launch(args);
    }


public static class MovieData {

        private final SimpleStringProperty movieName;
        private final SimpleStringProperty numSeats;

        private MovieData(String movieName,String numSeats) {
            this.movieName = new SimpleStringProperty(movieName);
            this.numSeats = new SimpleStringProperty(numSeats);
            
        }

        public String getMovieName() {
            return movieName.get();
        }

        public String getNumSeats() {
            return numSeats.get();
        }
        
       

       
    }
}