/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.MovieDAO;
import DAO.ShowTimeDAO;
import Model.Movie;
import Model.ShowTime;
import java.awt.Insets;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AdminViewShowtime extends Application {
    
    int movieId;
    public AdminViewShowtime(int movieId)
    {
        this.movieId=movieId;
    }

    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        Menu customerMenu = new Menu("Customers");
        // Create MenuItems
        MenuItem createMovieItem = new MenuItem("Create Movie");
        MenuItem allMovieItem = new MenuItem("All Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(createMovieItem, allMovieItem);

        createMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                CreateMovie createMovie = new CreateMovie();
                createMovie.start(primaryStage);
            }
        });

        allMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                AllMovie allMovie = new AllMovie();
                allMovie.start(primaryStage);
            }
        });

        Menu accountMenu = new Menu("Go");
        MenuItem gotoLogin = new MenuItem("back");
        accountMenu.getItems().addAll(gotoLogin);
        gotoLogin.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            	AdminHome login = new AdminHome();
                login.start(primaryStage);
            }
        });
        menuBar.getMenus().addAll(moviesMenu, accountMenu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        MovieDAO movieDAO=new MovieDAO();
        
        Text scenetitle = new Text("List of all showtimes for "+movieDAO.getMovieDetails(movieId).getMoviename());
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2,4); 
        
        TableView table = new TableView();
        
        TableColumn showtimeCol = new TableColumn("ShowTimes");
        showtimeCol.setMinWidth(200);
        showtimeCol.setCellValueFactory(new PropertyValueFactory<>("showtime"));

        ShowTimeDAO showtimeDAO=new ShowTimeDAO();
        List<ShowTime> showtimes= showtimeDAO.getAllShowtimes(movieId);
        final ObservableList<MovieData> data
            = FXCollections.observableArrayList(                      
                    
            );

       for(ShowTime showtime:showtimes){
            data.add(new MovieData(showtime.getShowtime()));
        }
       
        table.setItems(data); 
        table.getColumns().addAll(showtimeCol);
                  
        Button btnAdd = new Button();
        btnAdd.setText("Add ShowTime");
        btnAdd.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println(table.getSelectionModel().getSelectedIndex());
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);                
                AddShowtime addShowtime = new AddShowtime(movieId);
                addShowtime.start(primaryStage);
            }
        });
        grid.add(btnAdd, 2, 5);
        
        
        
        Button btnDelete = new Button();
        btnDelete.setText("Delete ShowTime");
        btnDelete.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                System.out.println(table.getSelectionModel().getSelectedIndex());
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);                
                showtimeDAO.deleteShowtime(showtimes.get(index).getShowtimeId());
                AdminViewShowtime allShowtime = new AdminViewShowtime(movieId);
                allShowtime.start(primaryStage);
            }
        });
        grid.add(btnDelete, 2, 6);
        
        grid.add(table, 2, 7);
        
        

        Scene scene = new Scene(root, 700, 550);

        primaryStage.setTitle("All Showtimes!");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }

    public static void main(String[] args) {
        Application.launch(args);
    }


public static class MovieData {

        private final SimpleStringProperty showtime;

        private MovieData(Timestamp timestamp) {
            this.showtime = new SimpleStringProperty(new SimpleDateFormat("MM/dd/yyyy HH:mm").format(timestamp));           
        }

        public String getShowtime() {
            return showtime.get();
        }

    }
}