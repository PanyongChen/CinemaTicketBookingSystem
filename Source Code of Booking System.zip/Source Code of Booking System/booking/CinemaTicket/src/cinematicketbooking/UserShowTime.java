/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.MovieDAO;
import DAO.ShowTimeDAO;
import Model.Movie;
import Model.ShowTime;
import java.awt.Insets;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class UserShowTime extends Application {
    
    int movieId;
    int userid;
    public UserShowTime()
    {
        this.movieId=48;
    }
    public UserShowTime(int userid,int movieId)
    {
        this.userid=userid;
        this.movieId=movieId;
    }

    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
       MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        // Create MenuItems
        MenuItem allMoviesItem = new MenuItem("All Movies");
        MenuItem searchMoviesItem = new MenuItem("Search Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(allMoviesItem, searchMoviesItem);

        allMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserAllMovie userAllMovie = new UserAllMovie(userid);
                userAllMovie.start(primaryStage);
            }
        });

        searchMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserSearchMovies userSearchMovie = new UserSearchMovies(userid);
                userSearchMovie.start(primaryStage);
            }
        });

        Menu bookingsMenu = new Menu("Bookings");
        // Create MenuItems
        MenuItem myBookingsItem = new MenuItem("My Bookings");
        bookingsMenu.getItems().addAll(myBookingsItem);
        myBookingsItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserBookings userBookings = new UserBookings(userid);
                userBookings.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        Menu accountMenu = new Menu("Go");
        MenuItem gotoLogin = new MenuItem("back");
        accountMenu.getItems().addAll(gotoLogin);
        gotoLogin.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            	CustomerHome login = new CustomerHome(userid);
                login.start(primaryStage);
            }
        });
        
        menuBar.getMenus().addAll(moviesMenu,bookingsMenu,accountMenu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        MovieDAO movieDAO=new MovieDAO();
        
        Text scenetitle = new Text("List of all showtimes for "+movieDAO.getMovieDetails(movieId).getMoviename());
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2,4); 
        
        TableView table = new TableView();
        
        TableColumn showtimeCol = new TableColumn("ShowTimes");
        showtimeCol.setMinWidth(200);
        showtimeCol.setCellValueFactory(new PropertyValueFactory<>("showtime"));

        ShowTimeDAO showtimeDAO=new ShowTimeDAO();
        List<ShowTime> showtimes= showtimeDAO.getAllShowtimes(movieId);
        final ObservableList<MovieData> data
            = FXCollections.observableArrayList(                      
                    
            );

       for(ShowTime showtime:showtimes){
            data.add(new MovieData(showtime.getShowtime()));
        }
       
        table.setItems(data); 
        table.getColumns().addAll(showtimeCol);
                  
        Button btnAdd = new Button();
        btnAdd.setText("Book Show");
        btnAdd.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println(table.getSelectionModel().getSelectedIndex());
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);                
                UserBookShow userBookShow = new UserBookShow(userid,movieId,showtimes.get(index).getShowtimeId());
                userBookShow.start(primaryStage);
            }
        });
        grid.add(btnAdd, 2, 5);
        
        
        
        Button btnDelete = new Button();        
        
        grid.add(table, 2, 6);
        
        

        Scene scene = new Scene(root, 700, 550);

        primaryStage.setTitle("All Showtimes!");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }


public static class MovieData {

        private final SimpleStringProperty showtime;

        private MovieData(Timestamp timestamp) {
            this.showtime = new SimpleStringProperty(new SimpleDateFormat("MM/dd/yyyy HH:mm").format(timestamp));           
        }

        public String getShowtime() {
            return showtime.get();
        }

    }
}

