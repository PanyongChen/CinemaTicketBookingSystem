/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import java.awt.Insets;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AdminHome extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        Menu customerMenu = new Menu("Customers");
        // Create MenuItems
        MenuItem createMovieItem = new MenuItem("Create Movie");
        MenuItem allMovieItem = new MenuItem("All Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(createMovieItem, allMovieItem);

        createMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                CreateMovie createMovie = new CreateMovie();
                createMovie.start(primaryStage);
            }
        });

        allMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                AllMovie allMovie = new AllMovie();
                allMovie.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        Menu accountMenu = new Menu("Account");
        MenuItem gotoLogin = new MenuItem("Log out");
        accountMenu.getItems().addAll(gotoLogin);
        gotoLogin.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            	Login login = new Login();
                login.start(primaryStage);
            }
        });
        
        menuBar.getMenus().addAll(moviesMenu,accountMenu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        
        Text scenetitle = new Text("Welcome To Cinema Booking Admin Panel!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2,4);
        
        Text createmessage = new Text("You can create new movie records!");
        createmessage.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(createmessage, 2,5);
        
        Text updatemessage = new Text("You can update existing movie records!");
        updatemessage.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(updatemessage, 2,6);
        
        Text deletemessage = new Text("You can delete existing movie records!");
        deletemessage.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(deletemessage, 2,7);

        root.getStyleClass().add("adminImage");
        Scene scene = new Scene(root, 500, 400);
        scene.getStylesheets().add(getClass().getResource("Hom.css").toExternalForm());
        primaryStage.setTitle("Welcome!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
