/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.MovieDAO;
import DAO.MovieTypeDAO;
import DAO.UserDAO;
import Model.Movie;
import Model.MovieType;
import Model.User;
import java.awt.Insets;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AdminViewMovie extends Application {
    int movieId;
    public AdminViewMovie()
    {
        this.movieId=48;
    }
    public AdminViewMovie(int movieId)
    {
        this.movieId=movieId;
    }

    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        Menu customerMenu = new Menu("Customers");
        // Create MenuItems
        MenuItem createMovieItem = new MenuItem("Create Movie");
        MenuItem allMovieItem = new MenuItem("All Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(createMovieItem, allMovieItem);

        createMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                CreateMovie createMovie = new CreateMovie();
                createMovie.start(primaryStage);
            }
        });

        allMovieItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                AllMovie allMovie = new AllMovie();
                allMovie.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        Menu accountMenu = new Menu("Go");
        MenuItem gotoLogin = new MenuItem("back");
        accountMenu.getItems().addAll(gotoLogin);
        gotoLogin.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            	AdminHome login = new AdminHome();
                login.start(primaryStage);
            }
        });
        menuBar.getMenus().addAll(moviesMenu, accountMenu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        
        Text scenetitle = new Text("View Movie Details!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2, 4);
        
        MovieDAO movieDAO=new MovieDAO();
        Movie movie=movieDAO.getMovieDetails(movieId);

        Label movieName = new Label("Movie Name:");
        grid.add(movieName, 2, 5);

        Label movieNameField = new Label(movie.getMoviename());
        grid.add(movieNameField, 3, 5);       

        grid.add(new Label("Movie Desc:"), 2, 6);
        Label movieDescField = new Label(movie.getMoviedesc());
        grid.add(movieDescField, 3, 6);       

        grid.add(new Label("Movie Type:"), 2, 7);
        Label movieTypeField = new Label(movie.getMovieType());
        grid.add(movieTypeField, 3, 7);     

        grid.add(new Label("Movie Address:"), 2, 8);
        Label addressField = new Label(movie.getMovieaddress());
        grid.add(addressField, 3, 8);

        grid.add(new Label("City:"), 2, 9);
        Label cityField = new Label(movie.getMoviecity());
        grid.add(cityField, 3, 9);

        grid.add(new Label("State:"), 2, 10);
        Label stateField = new Label(movie.getMoviestate());
        grid.add(stateField, 3, 10);

        grid.add(new Label("Country:"), 2, 11);
        Label countryField = new Label(movie.getMoviecountry());
        grid.add(countryField, 3, 11);

        grid.add(new Label("Zip:"), 2, 12);
        Label zipField = new Label(movie.getMoviezip());
        grid.add(zipField, 3, 12);
        
        grid.add(new Label("Movie Release Date:"), 2, 13);
        Label releaseDate = new Label(new SimpleDateFormat("MM/dd/yyyy").format(movie.getMoviereleasedate()));
        grid.add(releaseDate, 3, 13);
        
        Button btnEdit = new Button();
        btnEdit.setText("Edit Details");
        btnEdit.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {               
                AdminEditMovie adminEditMovie = new AdminEditMovie(movieId);
                adminEditMovie.start(primaryStage);
            }
        });
        grid.add(btnEdit, 2, 14);
        
        Button btnViewShowtime = new Button();
        btnViewShowtime.setText("Show Times");
        btnViewShowtime.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {               
                AdminViewShowtime adminViewShowtime = new AdminViewShowtime(movieId);
                adminViewShowtime.start(primaryStage);
            }
        });
        grid.add(btnViewShowtime, 2, 15);


        Scene scene = new Scene(root, 600, 560);
        

        primaryStage.setTitle("View Movie!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
