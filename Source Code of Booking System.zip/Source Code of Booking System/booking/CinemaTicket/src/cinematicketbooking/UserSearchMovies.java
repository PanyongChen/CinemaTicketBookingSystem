/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.MovieDAO;
import Model.Movie;
import java.awt.Insets;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class UserSearchMovies extends Application {
    int userid;
    public UserSearchMovies(int userid)
    {
        this.userid=userid;
    }
    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
          // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        // Create MenuItems
        MenuItem allMoviesItem = new MenuItem("All Movies");
        MenuItem searchMoviesItem = new MenuItem("Search Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(allMoviesItem, searchMoviesItem);

        allMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserAllMovie userAllMovie = new UserAllMovie(userid);
                userAllMovie.start(primaryStage);
            }
        });

        searchMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserSearchMovies userSearchMovie = new UserSearchMovies(userid);
                userSearchMovie.start(primaryStage);
            }
        });

        Menu bookingsMenu = new Menu("Bookings");
        // Create MenuItems
        MenuItem myBookingsItem = new MenuItem("My Bookings");
        bookingsMenu.getItems().addAll(myBookingsItem);
        myBookingsItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserBookings userBookings = new UserBookings(userid);
                userBookings.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        Menu accountMenu = new Menu("Go");
        MenuItem gotoLogin = new MenuItem("back");
        accountMenu.getItems().addAll(gotoLogin);
        gotoLogin.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            	CustomerHome login = new CustomerHome(userid);
                login.start(primaryStage);
            }
        });
        menuBar.getMenus().addAll(moviesMenu,bookingsMenu, accountMenu);



        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        
        Text scenetitle = new Text("List of all movies in the system!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2,4); 
        
        TableView table = new TableView();
        
        TableColumn movieNameCol = new TableColumn("Movie Name");
        movieNameCol.setMinWidth(200);
        movieNameCol.setCellValueFactory(new PropertyValueFactory<>("movieName"));

        TableColumn movieCityCol = new TableColumn("City");
        movieCityCol.setMinWidth(150);
        movieCityCol.setCellValueFactory(new PropertyValueFactory<>("city"));
        
        TableColumn movieTypeCol = new TableColumn("Movie Type");
        movieTypeCol.setCellValueFactory(new PropertyValueFactory<>("movieType"));
        movieTypeCol.setMinWidth(150);
        TableColumn movieRating = new TableColumn("Movie Rating");
        movieRating.setCellValueFactory(new PropertyValueFactory<>("movieRating"));
        movieRating.setMinWidth(100);
        MovieDAO movieDAO=new MovieDAO();
        List<Movie> movies= movieDAO.getAllMovies();
        final ObservableList<MovieData> data
            = FXCollections.observableArrayList(       
                  
                    
            );

       int rateI = 0,p;
       for(Movie movie:movies){
    	    String rate = new String();
    	    int rValue = getRating(rateI);
    	    for(p = 0; p < rValue; p ++) {
    	    	rate += "*";
    	    }
            data.add(new MovieData(movie.getMoviename(),movie.getMoviecity(),movie.getMovieType(), rate));
        }
       
        table.setItems(data); 
        table.getColumns().addAll(movieNameCol,movieCityCol,movieTypeCol,movieRating);
        
        
        Button btnView = new Button();
        btnView.setText("View Detail");
        btnView.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);
                UserViewMovie userViewMovie = new UserViewMovie(userid,movies.get(index).getMovieid());
                userViewMovie.start(primaryStage);
            }
        });
        grid.add(btnView, 2, 5);
        
        Button btnEdit = new Button();
        btnEdit.setText("Show Time");
        btnEdit.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                System.out.println(table.getSelectionModel().getSelectedIndex());
                int index=table.getSelectionModel().getSelectedIndex();
                System.out.println(index);
                UserShowTime userShowTime = new UserShowTime(userid,movies.get(index).getMovieid());
                userShowTime.start(primaryStage);
            }
        });
        grid.add(btnEdit, 2, 6);
        grid.add(table, 2, 7);
        
        

        Scene scene = new Scene(root, 700, 500);

        primaryStage.setTitle("All Movies!");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }
    public static int getRating(int i) {
    	Random rand = new Random();
    	int  n = rand.nextInt(50) + i;
    	return n % 5 + 1;
    }
    public static void main(String[] args) {
        Application.launch(args);
    }


public static class MovieData {

        private final SimpleStringProperty movieName;
        private final SimpleStringProperty city;
        private final SimpleStringProperty movieType;
        private final SimpleStringProperty movieRating;
        private MovieData(String movieName,String city, String movieType, String movieRating) {
            this.movieName = new SimpleStringProperty(movieName);
            this.city = new SimpleStringProperty(city);
            this.movieType = new SimpleStringProperty(movieType);
            this.movieRating = new SimpleStringProperty(movieRating);
        }

        public String getMovieName() {
            return movieName.get();
        }
        public String getMovieRating() {
        	return movieRating.get();
        }
       

        public String getCity() {
            return city.get();
        }

        public String getMovieType() {
            return movieType.get();
        }

       
    }
}