/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.UserDAO;
import Model.User;
import java.awt.Insets;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Register extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu menu = new Menu("Register/Login");
        // Create MenuItems
        MenuItem registerItem = new MenuItem("Register");
        MenuItem loginItem = new MenuItem("Login");

        // Add menuItems to the Menus
        menu.getItems().addAll(registerItem, loginItem);

        registerItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Register register = new Register();
                register.start(primaryStage);
            }
        });

        loginItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Login login = new Login();
                login.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        menuBar.getMenus().addAll(menu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);

        Text scenetitle = new Text("Registration Form!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2, 4);

        Label userName = new Label("User Name:");
        grid.add(userName, 2, 5);

        TextField userTextField = new TextField();
        grid.add(userTextField, 3, 5);

        Label pw = new Label("Password:");
        grid.add(pw, 2, 6);

        PasswordField pwBox = new PasswordField();
        grid.add(pwBox, 3, 6);

        grid.add(new Label("Name:"), 2, 7);
        TextField nameField = new TextField();
        grid.add(nameField, 3, 7);

        grid.add(new Label("Phone:"), 2, 8);
        TextField phoneField = new TextField();
        grid.add(phoneField, 3, 8);

        grid.add(new Label("Email:"), 2, 9);
        TextField emailField = new TextField();
        grid.add(emailField, 3, 9);

        grid.add(new Label("Address:"), 2, 10);
        TextField addressField = new TextField();
        grid.add(addressField, 3, 10);

        grid.add(new Label("City:"), 2, 11);
        TextField cityField = new TextField();
        grid.add(cityField, 3, 11);

        grid.add(new Label("State:"), 2, 12);
        TextField stateField = new TextField();
        grid.add(stateField, 3, 12);

        grid.add(new Label("Country:"), 2, 13);
        TextField countryField = new TextField();
        grid.add(countryField, 3, 13);

        grid.add(new Label("Zip:"), 2, 14);
        TextField zipField = new TextField();
        grid.add(zipField, 3, 14);

        Scene scene = new Scene(root, 500, 530);
        Label resgisterMessage = new Label("");
        Button btnLogin = new Button();
        btnLogin.setText("Register");
        btnLogin.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                UserDAO userDAO = new UserDAO();
                String username = userTextField.getText();
                String password = pwBox.getText();
                if (userDAO.userExists(username) > 0) {
                    resgisterMessage.setText("Username exists!");
                } else if (username.length() == 0 || password.length() == 0) {
                    resgisterMessage.setText("Username and password cannot be empty!");
                } else {                    
                    String name = nameField.getText();
                    String phone = phoneField.getText();
                    String email = emailField.getText();
                    String address = addressField.getText();
                    String city = cityField.getText();
                    String state = stateField.getText();
                    String country = countryField.getText();
                    String zip = zipField.getText();
                    String usertype = "customer";
                    User user = new User(-1, username, password, name, phone, email, address, city, state, country, zip, usertype);
                    int res = userDAO.insertUserDetails(user);
                    System.out.println(res);
                    if (res !=0) {
                        resgisterMessage.setText("Unable to process request!");
                    }  else {
                        resgisterMessage.setText("Successful resgistration! Please login!");                        
                    }
                }
            }
        });

        grid.add(btnLogin, 2, 15);

        grid.add(resgisterMessage, 2, 16);

        primaryStage.setTitle("Register!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
