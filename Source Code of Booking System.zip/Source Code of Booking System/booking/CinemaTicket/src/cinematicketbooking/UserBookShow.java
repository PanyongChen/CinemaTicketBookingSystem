/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import DAO.BookingDAO;
import DAO.MovieDAO;
import DAO.MovieTypeDAO;
import DAO.ShowTimeDAO;
import DAO.UserDAO;
import Model.Booking;
import Model.Movie;
import Model.MovieType;
import Model.User;
import java.awt.Insets;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class UserBookShow extends Application {
    int movieId;
    int showtimeId;
    int userid;
    public UserBookShow()
    {
        this.userid=3;
        this.movieId=48;
        this.showtimeId=1;
                
    }
    public UserBookShow(int userid,int movieId,int showtimeId)
    {
        this.userid=userid;
        this.movieId=movieId;
        this.showtimeId=showtimeId;
    }

    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu moviesMenu = new Menu("Movies");
        // Create MenuItems
        MenuItem allMoviesItem = new MenuItem("All Movies");
        MenuItem searchMoviesItem = new MenuItem("Search Movies");

        // Add menuItems to the Menus
        moviesMenu.getItems().addAll(allMoviesItem, searchMoviesItem);

        allMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserAllMovie userAllMovie = new UserAllMovie(userid);
                userAllMovie.start(primaryStage);
            }
        });

        searchMoviesItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserSearchMovies userSearchMovie = new UserSearchMovies(userid);
                userSearchMovie.start(primaryStage);
            }
        });

       Menu bookingsMenu = new Menu("Bookings");
        // Create MenuItems
        MenuItem myBookingsItem = new MenuItem("My Bookings");
        bookingsMenu.getItems().addAll(myBookingsItem);
        myBookingsItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                UserBookings userBookings = new UserBookings(userid);
                userBookings.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        Menu accountMenu = new Menu("Go");
        MenuItem gotoLogin = new MenuItem("back");
        accountMenu.getItems().addAll(gotoLogin);
        gotoLogin.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            	CustomerHome login = new CustomerHome(userid);
                login.start(primaryStage);
            }
        });
        
        menuBar.getMenus().addAll(moviesMenu,bookingsMenu,accountMenu);



        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(grid);
        
        Text scenetitle = new Text("Book Movie!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 2, 4);
        
        MovieDAO movieDAO=new MovieDAO();
        Movie movie=movieDAO.getMovieDetails(movieId);

        Label movieName = new Label("Movie Name:");
        grid.add(movieName, 2, 5);

        Label movieNameField = new Label(movie.getMoviename());
        grid.add(movieNameField, 3, 5); 
        
        grid.add(new Label("Movie show time:"), 2, 6);
        Label releaseDate = new Label(new SimpleDateFormat("MM/dd/yyyy HH:mm").format(movie.getMoviereleasedate()));
        grid.add(releaseDate, 3, 6);
        
        grid.add(new Label("Num seats:"), 2, 7);
        ListView<String> list = new ListView<String>();     
        ObservableList<String> items =FXCollections.observableArrayList ();
        for(int i=1;i<10;i++)
            items.add(i+"");
        list.setItems(items);
        list.setMaxHeight(100);
        grid.add(list, 3, 7);
        
         
        
        Button btnEdit = new Button();
        btnEdit.setText("Book Show");
        Label resgisterMessage = new Label("");
        btnEdit.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                BookingDAO bookingDAO = new BookingDAO();
                int numSeats=Integer.parseInt(list.getSelectionModel().getSelectedItem());
                Booking booking=new Booking(-1, userid, numSeats, showtimeId);
                int res = bookingDAO.insertBooking(booking);
                    System.out.println(res);
                    if (res !=0) {
                        resgisterMessage.setText("Unable to process request!");
                    }  else {
                        resgisterMessage.setText("Successful booking!");                        
                    }
            }
        });
        grid.add(btnEdit, 2, 8);
        grid.add(resgisterMessage, 2, 9);

        Scene scene = new Scene(root, 600, 560);
        

        primaryStage.setTitle("Book Show!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
