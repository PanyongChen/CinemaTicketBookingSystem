/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinematicketbooking;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class CinemaTicketBooking extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        // Create menus
        Menu menu = new Menu("Register/Login");
        // Create MenuItems
        MenuItem registerItem = new MenuItem("Register");
        MenuItem loginItem = new MenuItem("Login");

        // Add menuItems to the Menus
        menu.getItems().addAll(registerItem, loginItem);

        registerItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Register register = new Register();
                register.start(primaryStage);
            }
        });

        loginItem.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Login login = new Login();
                login.start(primaryStage);
            }
        });

        // Add Menus to the MenuBar
        menuBar.getMenus().addAll(menu);

        GridPane grid = new GridPane();

        grid.setHgap(10);
        grid.setVgap(10);
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setBottom(grid);
        
        Text resU = new Text("Recommended Resturant");
        resU.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(resU, 1,9);
        
        Text hotelU = new Text("Recommended Hotel");
        hotelU.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(hotelU, 5,9);
        
        List<Hyperlink> links = new ArrayList<>();
        Hyperlink linkR = new Hyperlink("http://www.yelp.com");
        Hyperlink linkH= new Hyperlink("http://www.booking.com");
        links.add(linkR);
        links.add(linkH);

        for(final Hyperlink hyperlink : links) {
            hyperlink.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent t) {
                    getHostServices().showDocument(hyperlink.getText());
                }
            });
        }

        
        grid.add(linkR, 6, 9);
        grid.add(linkH, 3, 9);
        root.getStyleClass().add("mainImage");
        Scene scene = new Scene(root, 482, 264);
        scene.getStylesheets().add(getClass().getResource("Hom.css").toExternalForm());
        primaryStage.setTitle("Welcome to the Cinema Ticket Booking System!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
